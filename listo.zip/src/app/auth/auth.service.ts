import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface User {
  id?: number;
  email: string;
  password: string;
  name?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  register(user: User): Observable<User> {
    // POST a /users para fake API (json-server)
    return this.http.post<User>(`${this.apiUrl}/users`, user);
  }

  login(email: string, password: string): Observable<User[]> {
    // GET a /users?email=...&password=...
    return this.http.get<User[]>(`${this.apiUrl}/users?email=${email}&password=${password}`);
  }
}

